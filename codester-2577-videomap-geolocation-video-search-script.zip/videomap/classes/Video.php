<?php
require_once 'google-api/vendor/autoload.php';

class Video
{
	protected $client;	
	protected $youtube_service;	
	function __construct($developer_key)
	{
        $this->client = new Google_Client();
        $this->client->setDeveloperKey($developer_key);

        // Define an object that will be used to make all API requests.
        $this->youtube_service = new Google_Service_YouTube($this->client);
	}

	public function search($q, $lat, $lng, $radius = '1000km', 
		$type = 'video', $order = 'date', $page_token = null, $maxResults = 50)
	{
		// parameters array for API calling
		$parameters = array();

		// initial videos array
		$videos = array();

		// final videos list with location points
		$videos_list = array();

		// prepear parameters. Set search query
		$parameters['q'] = $q;
		$parameters['order'] = $order;
		$parameters['maxResults'] = $maxResults;


		// Set location and location radius values
		if (isset($lat) && isset($lng)) {
			$parameters['location'] = "$lat, $lng";
			$parameters['locationRadius'] = "$radius";
		}
		
		// Set next page token for pagination
		if(isset($page_token)){
			$parameters['pageToken'] = $page_token;
		}

		// Set search result type, the default value is 'video'
		$parameters["type"] = $type;
		try{
			// Call search->listSearch method to retrive results matching the query
			$result = $this->youtube_service->search->listSearch('id,snippet', $parameters);

			// If there is more results, then set the next_page_token to load more results 
			$videos_list['next_page_token'] = null;
			$videos_list['prev_page_token'] = null;
			if(isset($result['nextPageToken'])){
				$videos_list['next_page_token'] = $result['nextPageToken'];
			}

			if(isset($result['prevPageToken'])){
				$videos_list['prev_page_token'] = $result['prevPageToken'];
			}
			// Push video id into videos array
			foreach ($result as $video) {
				array_push($videos, $video['id']['videoId']);
			}

			// Create a string of videos ids seperated by comma to reduce server calls into one call
			$video_ids = join(',', $videos);

			// Retrive snippet and recording details for each video
			$videos_details = $this->youtube_service->videos->listVideos('snippet, recordingDetails', array(
			    'id' => $video_ids
			    ));

			
			// Add video data to Videos_list array
			foreach ($videos_details as $video) {
				$videos_list['items'][] = array(
					"title" => $video['snippet']['title'],
					"id" => $video['id'],
					"lat" => $video['recordingDetails']['location']['latitude'],
	                "lng" => $video['recordingDetails']['location']['longitude']
				);
			}

			if($videos_list['items'] == false || count($videos_list['items']) < $maxResults){
				$videos_list['next_page_token'] = null;
				$videos_list['prev_page_token'] = null;
			}
			// return the final result as json format
			return json_encode($videos_list, JSON_PRETTY_PRINT);
		

		} catch (Google_Service_Exception $e) {

			return json_encode(
				array("error_type" => "service error", 
					  "error_message" => $e->getMessage()));
		  } catch (Google_Exception $e) {

		  	return json_encode(
		  		array("error_type" => "client error", 
		  			  "error_message" => $e->getMessage()));
		  } catch(Exception $e){

			return json_encode(
		  		array("error_type" => "connection error", 
		  			  "error_message" => $e->getMessage()));		  	
		  }		
	}

}