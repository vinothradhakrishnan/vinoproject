var markers = [];
var markers_pages = [];
var final_list = [];
var appendMarker;
var minDistance;
var lins;
var map;
var markerCluster;
var clearMarkers2;
var div;
var getMarkers;
var search_options;
var meregeMarker;
var getAllMarkers;
var search_url = "search.php";
var is_ajax_work = 0;
var options = {
    imagePath: 'assets/images/marker-clusterer/',
    maxZoom: 20
};

$(document).ready(function() {
    // initial location of the map
    var center = new google.maps.LatLng(-27.46834, 153.02365);

    // initalize google map
    map = new google.maps.Map(document.getElementById('map'), {
        zoom: 16,
        mapTypeId: google.maps.MapTypeId.ROADMAP,
        center: center,
        styles: [{
            stylers: [{
                visibility: 'simplified'
            }]
        }, {
            elementType: 'labels',
            stylers: [{
                visibility: 'on'
            }]
        }, {
            "featureType": "poi",
            "elementType": "labels",
            "stylers": [{
                "visibility": "off"
            }]
        }],
        mapTypeControl: true,
        mapTypeControlOptions: {
            position: google.maps.ControlPosition.RIGHT_TOP,
            style: google.maps.MapTypeControlStyle.DROPDOWN_MENU,
        }
    });

    // Run a listener once when the map loads to show a beginning message
    google.maps.event.addListenerOnce(map, 'idle', function() {
        Materialize.toast('Start Search and have FUN!!!', 4000);
    });

    map.addListener('click', function(){
        for (var i = markers.length - 1; i >= 0; i--) {
            markers[i].setAnimation(null);
        }
    });

    // Handle user search
    $("#search-form").submit(function(event) {
        // Stop form from submitting normally
        event.preventDefault();
        if(is_ajax_work == 0){

            // Get values from elements on the page:
            $form = $(this);
            url = $form.attr("action");

            // calculate the radius of the map to search
            // the raduis is the minimum distance between the center of the map and the map bounds
            var minDistance = Math.min(calcDistance(map.getCenter(), map.getBounds().getNorthEast()), calcDistance(map.getCenter(), new google.maps.LatLng(map.getBounds().getNorthEast().lat(), map.getCenter().lng())), calcDistance(map.getCenter(), new google.maps.LatLng(map.getCenter().lat(), map.getBounds().getNorthEast().lng())));
            
            // initalize search parameters
            search_options = {
                q: $("#q").val(),
                order: $("#order").val(),
                lat: map.getCenter().lat(),
                lng: map.getCenter().lng(),
                rad: minDistance
            };

            // retrive the videos list
            getVideos(url, search_options);
        }
    });

    // show the markers related to the page in pagination section
    $(document).on("click", ".page", function() {
        $('.page').removeClass('active');
        $(this).addClass('active');
        
        if (markerCluster) {
            markerCluster.clearMarkers();
        }
        markers = markers_pages[div.find('.page').index(this)];
        markerCluster = new MarkerClusterer(map, markers, options);
        markerCluster.fitMapToMarkers();
    });    

    // this function connect to the server and returns a list of videos based on user query and search options
    function getVideos(url, search_options, init = 1) {
        // prevent the execution if there is a serch running on
        if(is_ajax_work == 1){
            return;
        }
        is_ajax_work = 1;
        // show a loader while retriving data
        $('#map').prepend('<div class="progress"><div class="indeterminate"></div></div>');

        // post data to the server
        $.post(url, search_options, function(data) {

            // when the data loaded, remove the loader
            $('.progress').remove();

            // convert result to JSON format
            var result = jQuery.parseJSON(data);

            // update serch_option next page token for pagination 
            search_options.pageToken = result.next_page_token;

            // if the .post reterns data then
            if (result.items != null) {

                // if the search button is the source of event, then show the pagination and clear
                // marker cluster, markers, markers_pages, and final_list of markers
                if (init == 1){
                    markers_pages = [];
                    final_list = [];
                    initPagination();
                }

                // initaize markers
                markers = [];

                // show message of the number of reternd markers
                Materialize.toast(result.items.length + ' videos founded!', 2000);

                // append the videos to the markers array
                for (var i = 0; i < result.items.length; i++) {
                    appendMarker(result.items[i].lat, result.items[i].lng, result.items[i].title, result.items[i].id);
                };

                // add the markers to marker_pages array so the user can paginate it
                markers_pages.push(markers);
               
                // clear marker clusters to show the new markers
                if (markerCluster) {
                    markerCluster.clearMarkers();
                }
                // initailize markerCluster with the markers list
                markerCluster = new MarkerClusterer(map, markers, options);
                markerCluster.fitMapToMarkers();

                // if the more button clicked, show the next page number
                if (init != 1) {
                    $('.page').last().after('<li class="page waves-effect"><a href="#!">' + (markers_pages.length) + '</a></li>');
                    $('.page').removeClass('active');
                    $('.page').last().addClass('active');
                }
                return 1;
            } else {
                // if there is no videos, show a message 
                Materialize.toast('No videos founded in this palce', 4000);
                return 0;
            }
        }).always(function(){
            // when finish, set ajax working flage to 0 so the user can search again or load more videos
            is_ajax_work = 0;
        }).error(function(data){
            $('.progress').remove();
            Materialize.toast('Could not connect to the server', 4000, 'error');
        });
    }

    // this function append the pagination div into the map, this function called from the search form
    function initPagination() {
        // Remove old apgination div
        $('.pagination').remove();

        // Create a jQuery object for pagination div
        div = $('<div><ul class="pagination rt">\
        <li class="page waves-effect active"><a href="#!">1</a></li>\
        <li class="waves-effect more"><a href="#!">More<i class="material-icons">chevron_right</i></a></li>\
        </ul></div>'); //jQuery-object

        // append the patination div to bottom of the map
        map.controls[google.maps.ControlPosition.BOTTOM_CENTER].push(div[0]);

        // A click event for the "more" button to load the next videos list
        $('.more').click(function(){
            // If the pageToken is null, this indicate that there is no more videos to load from youtube.
            if(search_options.pageToken == null){
                Materialize.toast('No more videos founded in this palce', 4000);
            }else{
                getVideos(search_url, search_options, 0);    
            } 
        });
    }


    function getAllMarkers() {
        final_list = [];
        for (var i = 0; i < markers_pages.length; i++) { // markers pages
            for (var x = 0; x < markers_pages[i].length; x++) { // inside a page list
                meregeMarker(markers_pages[i][x]);
            }
        }
        console.log(final_list.length);
        if (final_list.length != 0) {
            if (markerCluster) {
                markerCluster.clearMarkers();
            }
            markerCluster = new MarkerClusterer(map, final_list, options);
            markerCluster.fitMapToMarkers();
        }
    }

    function meregeMarker(marker) {
        //console.log(marker);
        added = 0;
        if (final_list.length != 0) {
            for (var i = 0; i < final_list.length; i++) {
                //console.log(final_list[i]);
                p = final_list[i].getPosition();
                if (p.equals(marker.getPosition())) {
                    final_list[i].videos_list = final_list[i].videos_list.concat(marker.videos_list);
                    added = 1;
                }
            }
        }
        if (added == 0) {
            final_list.push(marker);
        }
    }

    // append a point to the markers list, the point is a video location
    function appendMarker(lat, lng, title, id) {
        // create a video object containig the video information- id and title
        var video = {
            id: id,
            title: title
        };

        // a flage indicating that the location of the video is new or not, some videos have idintical recording location points- lat and long, so instead of creating multiple markers on the same point we will create one marker and append the videos to it.
        var newMarker = true;

        // Check if there are markers in the markers array
        if (markers.length != 0) {

            // Create a point object from video lat an long
            p = new google.maps.LatLng(lat, lng);

            // Loop through the markers array
            for (var i = 0; i < markers.length; i++) {
                // if the new video location is similar to any of markers location in the markers array, then add the video information to that marker
                if (p.equals(markers[i].getPosition())) {
                    newMarker = false;
                    markers[i].videos_list.push({
                        video
                    });

                    // if the marker has more than one video, then change the marker icon to red
                    if (markers[i].videos_list.length > 1) {
                        markers[i].title = markers[i].videos_list.length + " in this location.";
                        markers[i].icon = "assets/images/marker-icon-multiple.png"
                    }

                    break;
                }
            };
        };

        // if the markers array is empty or the marker is a new marker then add it to the markers array
        if (newMarker) {
            var m = new google.maps.Marker({
                position: new google.maps.LatLng(lat, lng),
                icon: "assets/images/marker-icon.png",
                animation: null,
                draggable: true,
                opend: false,
                title: title,
                vid: id,
                videos_list: [{
                    video
                }]
            });

            // add a click listener to show the videos of the marker
            m.addListener('click', handle_marker_click);

            // add the marker to the markers array
            markers.push(m);
        }
        return m;
    }

    // calculate the distance between two points on the map
    function calcDistance(p1, p2) {
        return (google.maps.geometry.spherical.computeDistanceBetween(p1, p2));
    }


    function showGoogleAds() {
        var ad = '<ins class="adsbygoogle responsive" \
        style="display:inline-block;"\
            data-ad-client="'+config.ad_client_id+'"\
            ></ins>';
        var adNode = document.createElement('div');
        adNode.innerHTML = ad;
        map.controls[google.maps.ControlPosition.TOP_CENTER].push(adNode);
        google.maps.event.addListenerOnce(map, 'tilesloaded', function() {
            (adsbygoogle = window.adsbygoogle || []).push({});
        });
    }
    if(config.show_ads)
        showGoogleAds();

    function handle_marker_click() {

        if (this.getAnimation() !== null) {
            this.setAnimation(null);
            this.opend = false;
        } else {
            this.setAnimation(google.maps.Animation.BOUNCE);
            this.opend = true;
            var iframe = '<iframe id="ytplayer" type="text/html" width="640" height="390" src="http://www.youtube.com/embed/' + this.vid + '"/>';
            $('#modal1').html(iframe);
            $('#modal1').prepend('<div class="progress video-progress"> <div class="indeterminate"></div> </div>');
            $('#ytplayer').on('load', function() {
                $('.video-progress').remove();
            });
            var videos = '';
            for (var i = 0; i < this.videos_list.length; i++) {
                videos = videos + '<img alt="' + this.videos_list[i].video.title + '"' + 'data-type="youtube"' + 'data-videoid="' + this.videos_list[i].video.id + '"' + 'data-description="' + this.videos_list[i].video.title + '">';
            }
            $('#modal1').html('<div id="gallery" style="display:none;">' + videos + '</div>');
            $("#gallery").unitegallery({
                thumb_height: 100,
                thumb_width: 100,
                gallery_height: 700,
                thumb_overlay_opacity: 0,
                thumb_loader_type: "light",
                strip_control_avia: false
            });
            $('#modal1').openModal({
                complete: function() {
                    $('#modal1').html("");
                }
            });
        }
    }

    // Create the search box and link it to the UI element.
    var input = document.getElementById('pac-input');
    var searchBox = new google.maps.places.SearchBox(input);

    var markers = [];
    // Listen for the event fired when the user selects a prediction and retrieve
    // more details for that place.
    searchBox.addListener('places_changed', function() {
        var places = searchBox.getPlaces();
        if (places.length == 0) {
            return;
        }
        // Clear out the old markers.
        markers.forEach(function(marker) {
            marker.setMap(null);
        });
        markers = [];
        // For each place, get the icon, name and location.
        var bounds = new google.maps.LatLngBounds();
        places.forEach(function(place) {
            var icon = {
                url: place.icon,
                size: new google.maps.Size(71, 71),
                origin: new google.maps.Point(0, 0),
                anchor: new google.maps.Point(17, 34),
                scaledSize: new google.maps.Size(25, 25)
            };
            // Create a marker for each place.
            markers.push(new google.maps.Marker({
                map: map,
                icon: icon,
                title: place.name,
                position: place.geometry.location
            }));
            if (place.geometry.viewport) {
                // Only geocodes have viewport.
                bounds.union(place.geometry.viewport);
            } else {
                bounds.extend(place.geometry.location);
            }
        });
        map.fitBounds(bounds);
    });
});